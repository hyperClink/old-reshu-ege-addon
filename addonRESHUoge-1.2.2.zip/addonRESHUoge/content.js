chrome.runtime.onConnect.addListener(function (externalPort) {
  externalPort.onDisconnect.addListener(function () {
    if (typeof observer !== 'undefined' && typeof port !== 'undefined') {
      observer.disconnect();
      port.disconnect();
    };
  });
});

var buttons = document.querySelector('input[value="Отправить учителю"]');
if (buttons == null) {
  var buttons = document.querySelector('input[value="Сохранить"]');
}
buttons.addEventListener('click',function(){
  chrome.runtime.sendMessage({message:"showingAns", do: false});
});

var testInps = document.getElementsByClassName("test_inp");
var sols = document.getElementsByName('nosols');
var test_id = document.getElementsByName('test_id');
var stat_id = document.getElementsByName('stat_id');
if (stat_id[0] != undefined) {
  stat_id[0].remove();
};

var maxTime;

var hasCTasks;
for (var i = 0; i < testInps.length; i++) {
  if (testInps[i].name.match(/answer_([0-9]*?)_c/g) !== null) {
    hasCTasks = true;
  };
};

//checks if the test was created from a template, which would mean that its random nature is unsupported due to how my extension works :(
var testContent = document.getElementsByClassName('content');
var isRandomized;
for (var i = 0; i < testContent.length; i++) {
    if (testContent[i].innerHTML.indexOf('Вариант составлен по шаблону') > -1) {
        isRandomized = true;
    }
}

var countdChecked = false;
var answChecked = true;

var observer;
var port;

function exchange(data) {
  chrome.runtime.sendMessage(data, function(response) {
    switch (response.type) {

      case "auto":
      if (response.do) {
        chrome.runtime.sendMessage({message:"auto", do: false});
        exchange({message:"getAnsAuto"});
      };
      break;

      case "ansAuto":
      if (response.ansAuto != null && response.ansAuto != undefined) {
        var readyAns = response.ansAuto;
        var z = 0;
          for (var i = 0; i < testInps.length; i++) {
            if (testInps[i].name.match(/answer/g) == "answer") {
              testInps[i].value = readyAns[z];
              z++;
            };
          };
        exchange({message:"getTime"});
      };
      break;

      case "sendTime":
        document.getElementById('timer').value = response.sendTime;
        modifyPage(answHax2);
      break;

    };
  });
};

function modifyPage(snippet) {
  var script = document.createElement('script');
  script.textContent = snippet;
  (document.head||document.documentElement).appendChild(script);
  script.remove();
};

var timerIni = '(' + function() {
  clearTimeout(window.ticker);
  window.tick();
} + ')();';

var timerRnm = '(' + function() {
  ticker = window.setInterval(tick,1000);
} + ')();';

var timerStp = '(' + function() {
  clearTimeout(window.ticker);
} + ')();';

var answHax = '(' + function() {
  submit_form();
} + ')();';

var answHax2 = '(' + function() {
  $(document).ready(function(){
    submit_form();
  });
} + ')();';

var rtview = document.getElementById("rtview");

exchange({message:"getAuto"});

chrome.runtime.onMessage.addListener(
    function(message, sender, sendResponse) {
      console.log(message.type);
        switch(message.type) {

          case "hasCTasks":
              sendResponse({type:"hasCTasks", state:hasCTasks});
          break;

          case "isRandomized":
              sendResponse({type:"isRandomized", state:isRandomized});
          break;

          case "nosolsUndefined":
              sendResponse({type:"nosolsUndefined", state: sols[0] === undefined});
          break;

          case "countdState":
          if (typeof maxTime !== "undefined") {
            sendResponse({type:"countdState", state: countdChecked, limit:true});
            if (countdChecked) {
              port = chrome.runtime.connect({name: "currTime"});

              port.onDisconnect.addListener(function(event) {
                observer.disconnect();
              });

              observer = new MutationObserver(function(mutations){
                mutations.forEach(function(mutation){
                  port.postMessage({time:document.getElementById('timer').value});
                });
              });

              var config = {characterData: false, attributes: false, childList: true, subtree: false};
              observer.observe(rtview, config);

              }else{
              if (observer != undefined){
                observer.disconnect();
              };
            };
          }else{
            sendResponse({type:"countdState", state: true, limit:false});
          };
          break;

          case "answState":
              sendResponse({type:"answState", state: answChecked});
          break;

          case "tmPos":
              sendResponse({type:"tmPos", pos:document.getElementById('timer').value});
          break;

          case "maxTime":
          if (typeof maxTime !== 'undefined') {
            sendResponse({type:"maxTime", max:maxTime});
          }else{
            sendResponse({type:"maxTime", max:"1:00:00"});
          };
          break;

          case "setTimer":
            document.getElementById('timer').value = message.time;
            if (typeof maxTime !== 'undefined') {
              var TIMEMAX = parseInt(message.max)+1;

              var timerSet = '(' + function(TIMEMAX) {
                t = document.getElementById('timer').value;
                document.getElementById('timer').value = t;
                document.getElementById('tview').innerHTML=ftime(t);
                document.getElementById('dtview').innerHTML=ftime(t);
                document.getElementById('rtview').innerHTML=ftime(TIMEMAX-t);
                document.getElementById('drtview').innerHTML=ftime(TIMEMAX-t);
              } + ')(' + JSON.stringify(TIMEMAX) + ')';

              modifyPage(timerSet);
            };
          break;

          case "ticker":
            if (message.set) {
              if (confirm('ВНИМАНИЕ! Автоотсчёт сдаст работу учителю по истечении времени АВТОМАТИЧЕСКИ. Вы точно хотите его активировать?')) {
                document.getElementById('timer').value = 0;
                modifyPage(timerRnm);
                countdChecked = true;
              };
            } else {
              modifyPage(timerStp);
              countdChecked = false;
            };
          break;

          case "sols":
            if (message.set) {
              sols[0].className = " ";
              answChecked = true;
            } else {
              sols[0].className = "test_inp";
              answChecked = false;
            };
          break;

          case "hax":
          test_id[0].remove();
          if (sols[0] !== undefined) {
            sols[0].className = " ";
          };

          if (hasCTasks) {
            chrome.runtime.sendMessage({message:"cpartAns", do: true});
          };

          if (isRandomized) {
            chrome.runtime.sendMessage({message:"randomTemplate", is: true});
          };

          var redir = window.location.toString();

          if (message.auto) {
            //saves the timer and a link to the test (non-identifying not private information)
            chrome.runtime.sendMessage({message:"sendTime", time: document.getElementById('timer').value});
            chrome.runtime.sendMessage({message:"redir", redir: redir});

            chrome.runtime.sendMessage({message:"auto", do: true});
          }else{
            window.open(redir);
            if (!hasCTasks) {
              chrome.runtime.sendMessage({message:"showingAns", do: true});
            };
          };
          //modifyPage(submitMethodToGet);
          modifyPage(answHax);
          break;
        };
    });

//IMPORTANT -- ONLY GET MAXTIME A F T E R RUNNING TICK() ONCE
if (rtview != undefined) {
  modifyPage(timerIni);
  maxTime = rtview.innerText;
};

if (sols[0] !== undefined) {
  sols[0].className = " ";
};

chrome.runtime.sendMessage({"message": "activate_icon"});
