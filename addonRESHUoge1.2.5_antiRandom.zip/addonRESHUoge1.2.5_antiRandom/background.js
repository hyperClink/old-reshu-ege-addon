var showAns = false;
var doAuto = false;
var cpartAnsShow = false;
var time = 1000;
var redir;
var answersParsed;

chrome.extension.onMessage.addListener(
    function(request, sender, sendResponse) {
      switch (request.message) {
        case "activate_icon":
          chrome.pageAction.show(sender.tab.id);
        break;

        case "showingAns":
          showAns = request.do;
        break;

        case "getShowingAns":
          sendResponse({type:"showingAns", do:showAns});
        break;

        case "auto":
          doAuto = request.do;
        break;

        case "getAuto":
          sendResponse({type:"auto", do:doAuto});
        break;

        case "ansAuto":
          answersParsed = request.answersParsed;
        break;

        case "getAnsAuto":
          sendResponse({type:"ansAuto", ansAuto:answersParsed});
        break;

        case "cpartAns":
          cpartAnsShow = request.do;
        break;

        case "getCpartAns":
          sendResponse({type:"cpartAns", do:cpartAnsShow});
        break;

        case "sendTime":
          time = request.time;
        break;

        case "getTime":
          sendResponse({type:"sendTime", sendTime:time});
        break;

        case "setTimer":
          sendResponse({type:"sendTime", sendTime:time});
        break;

        case "redir":
          redir = request.redir;
        break;

        case "getRedir":
          sendResponse({type:"redir", redir:redir});
        break;


        default:
          console.log("invalid request" + " " + request.message);
        break;

      };
});
