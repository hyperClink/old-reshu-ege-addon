function exchange(data) {
  chrome.runtime.sendMessage(data, function(response) {
    switch (response.type) {

      case "auto":
      if (response.do) {
        var answersParsed = [];
        var answers = document.getElementsByClassName("res_row");
        for (var i = 0; i < answers.length; i++) {
          answersParsed.push(answers[i].cells[4].innerText);
        };
        chrome.runtime.sendMessage({message:"ansAuto", answersParsed: answersParsed});
        document.body.innerHTML = "Теперь можно закрыть данную страницу."
        exchange({message:"getRedir"});
      };
      break;

      case "redir":
        window.open(response.redir);
      break;

      case "showingAns":
      console.log(response.do);
        if (response.do) {
          chrome.runtime.sendMessage({message:"showingAns", do: false});
          var header = document.getElementsByClassName("new_header");
          for (var i = 0; i < 2; i++) {
            header[i].innerHTML = "Ответы (работа не отправлена учителю)";
          };
        };
      break;

      case "cpartAns":
        if (response.do) {
          chrome.runtime.sendMessage({message:"cpartAns", do: false});
          for (var i = 0; i < 2; i++) {
            var buttons = document.querySelector('input[value="Подвести итоги"]');
            buttons.value = "ПОКАЗАТЬ ОТВЕТЫ"
            buttons.addEventListener('click',function(){
              chrome.runtime.sendMessage({message:"showingAns", do: true});
            });
          };

          var header = document.getElementsByClassName("new_header");
          for (var i = 0; i < 2; i++) {
            header[i].innerHTML = "Ответы (работа не отправлена учителю)";
          };
        };
      break;

    };
  });
};

exchange({message:"getShowingAns"});

exchange({message:"getCpartAns"});

exchange({message:"getAuto"});
